<footer>
    <link rel="stylesheet" href="footer.css">
    <p>&copy; <?php echo date("Y"); ?> Habesha College Computer Science Students. All rights reserved.</p>
    <p>
        <a href="privacy.php">Privacy Policy</a> | 
        <a href="terms.php">Terms of Service</a>
    </p>
</footer>